(function($) {

	MediaElementPlayer.prototype.buildvisualcontrols = function(player, controls, layers, media) {
		if (!player.isVideo)
			return;

		// add visual controls (HSV)
	}

})(mejs.$);