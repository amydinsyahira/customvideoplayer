This XAP silverlight component is a fork of [MediaElement.js](https://github.com/johndyer/mediaelement/tree/master/src/silverlight) Silverlight component to match video.js requirements.
Thanks to John Dyer for his work.

To build it, Visual Studio 2013 Express is required.