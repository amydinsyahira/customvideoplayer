describe('Dummy', function() {
  it('should success on true===true', function() {
    (true).should.equal(true);
  });
});
