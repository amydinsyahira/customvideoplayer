videojs-osmf
============

An OSMF based playback technology for Video.JS. The goals of this are as follows;

1. CDN agnostic HDS
2. Akamai HD2 HDS
3. MPEG DASH via Dash.as
