

var fixture = document.createElement('div');
fixture.id = 'qunit-fixture';
document.body.appendChild(fixture);
