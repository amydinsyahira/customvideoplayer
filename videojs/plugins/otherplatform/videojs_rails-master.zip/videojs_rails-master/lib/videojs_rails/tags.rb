require 'videojs_rails/tags/tag'
require 'videojs_rails/tags/video'
require 'videojs_rails/tags/caption'
require 'videojs_rails/tags/source'

module VideojsRails
  module Tags
  end
end
