module VideojsRails
  VERSION = '4.12.14'
end
