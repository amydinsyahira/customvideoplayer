#Video.js Plugin of Danmu

Video.js 的一个弹幕插件，仅仅实现了加载显示弹幕的功能。

弹幕核心来自于：https://github.com/jabbany/ABPlayerHTML5

演示: http://catofes.github.io/videojsABdm/demo

This is a plugin for video.js which show comments during playing. You can see everyone's comments scroll across the video.

Demo: http://catofes.github.io/videojsABdm/demo


Thanks To :

-Video.js

-Bootstrap

-ABPlayerHTML5
