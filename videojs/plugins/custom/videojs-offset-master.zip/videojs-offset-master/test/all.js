test("the base function exists", function() {
  ok(vjsoffset);
});
