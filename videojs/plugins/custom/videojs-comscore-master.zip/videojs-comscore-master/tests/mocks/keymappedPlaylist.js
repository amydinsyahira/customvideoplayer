var keymappedPlaylist = [{
    customId: 45234532,
    displayName: 'Zencoder test video',
    brand: 'Zencoder',
    fileLocation: 'http://vjs.zencdn.net/v/oceans.mp4'
  },
  {
    customId: 'adas23490d8fasd9f8asd9f08ad0f',
    displayName: 'Test Video',
    programme: 'Hampton Testing',
    length: 900000, // 15 minutes
    author: 'Brandon Aaskov',
    advertisement: false,
    brand: 'Fullscreen',
    exclusive: true,
    free: false,
    liveStream: false,
    class: 'vc12',
    fileLocation: 'https://s3-us-west-1.amazonaws.com/fullscreen-tv/uploads/balloon+jump+480p.mp4'
  }
];