var playlist = [{
    id: 45234532,
    name: 'Zencoder test video',
    publisher: 'Zencoder',
    url: 'http://vjs.zencdn.net/v/oceans.mp4'
  },
  {
    id: 'adas23490d8fasd9f8asd9f08ad0f',
    name: 'Test Video',
    show: 'Hampton Testing',
    duration: 900000, // in ms
    publisher: 'Brandon Aaskov',
    ad: false,
    url: 'https://s3-us-west-1.amazonaws.com/fullscreen-tv/uploads/balloon+jump+480p.mp4'
  }
];