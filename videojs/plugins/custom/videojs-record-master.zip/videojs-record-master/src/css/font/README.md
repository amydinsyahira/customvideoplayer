Font
====

This directory contains the additional font used in the videojs-record plugin.

Edit the Font
-------------

To modify your generated font, use the `selection.js` file, located in the `css/font`
directory. You can import this file into the [IcoMoon](https://icomoon.io/app)
app. All the tags (class names) and the Unicode points of your glyphs are saved in
this file.

See the documentation for more info on how to use this package: https://icomoon.io/#docs/font-face