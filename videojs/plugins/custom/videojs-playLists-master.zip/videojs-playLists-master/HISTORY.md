0.2.0 / 2013-11-20
==================

  * Fixed issue which avoided the playlist to work with latest versions of videojs


0.1.1 / 2013-08-26
==================

  * Fixed issue with iOS devices in which the plugin won't work

0.1.0 / 2013-07-08
==================

  * added example, updated gruntfile
  * added option to pass in function to get video source (for use with s3 tokens)
  * Resume on finish & next/prev
  * Addding demo to readme
  * removed example in favor of demo
  * changed alerts to console.logs
  * Created demo
  * initial commit
