video-js-4-plugins
==================

A collection of plugins for Video.js 4.x


Just starting to throw these up, each will have a readme with links to a demo and how-to.
