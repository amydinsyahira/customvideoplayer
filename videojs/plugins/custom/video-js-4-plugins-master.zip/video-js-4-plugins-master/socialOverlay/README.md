Creating this plugin: http://tastybytes.net/creating-a-video-js-plugin/

Demo: http://brianpkelley.github.io/video-js-4-plugins/demos/socialOverlay.html

Usage: https://github.com/brianpkelley/video-js-4-plugins/blob/gh-pages/demos/socialOverlay.html
