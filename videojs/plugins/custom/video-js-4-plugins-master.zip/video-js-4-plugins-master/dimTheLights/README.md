
# Usage

### HTML:
```
<video ... data-setup='{"plugins":{"dimTheLights":{}}}'>
```

### Javascript:
```
videojs('VIDEO_ID', {plugins: {dimTheLights: {}}});
```
