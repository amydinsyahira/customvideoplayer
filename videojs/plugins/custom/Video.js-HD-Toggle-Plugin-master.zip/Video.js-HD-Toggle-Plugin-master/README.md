Video JS HD Toggle Plugin 
*************************

Demo: http://radiations3.com/videojs_hd_plugin/
***********************************************

***How it works:***

1. It provides the way to toggle between HD and non HD source with a click of one HD button. 
2. It is very simple and easy to use.
3. By clicking on HD button, Video JS player changes the source from HD to non HD source and vice versa. 

***How to use:***

1. I have done it by two ways:
 
	a. By getting sources from video tag.
		HD = "HDsrc" nonHD = "noHDsrc"

		Example: http://jsfiddle.net/Hussnain1/unrjrqee/

	b. By providing arguments to function called in a script tag.(By JavaScript)
	   
		Example: http://jsfiddle.net/Hussnain1/ctLmx4fz/1/
2. Very easy to change the design of HD button because of its small and easy css.


		
