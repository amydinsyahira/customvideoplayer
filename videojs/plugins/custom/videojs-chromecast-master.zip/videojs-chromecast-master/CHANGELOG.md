CHANGELOG
=========

## HEAD (Unreleased)
*(no changes)*

## 1.1.1 (13.04.2014)
* The Chromecast will no longer stay paused after seeking. (#10)
* If casting is ended while playing, the browser seeks to the last position and plays. (#10)

## 1.1.0 (18.02.2014)
* Added `bower.json`. It can now be installed by calling `bower install videojs-chromecast`. (#8)
* Added WebM and HLS support. (#9)
* Fixed compatibility with Video.JS v4.12.0.

## 1.0.0 (22.09.2014)
* First release
