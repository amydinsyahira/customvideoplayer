# Update

Does not work on Mobile Devices!

#v1.4

1. Comments
2. Spacing is correct
3. Fixed fullscreen with fullscreen.js!

#v1.3

1. Set what the HTML will be when  video is done

#v1.2.2

1. Bug Fix
2. Shows Video When Video Starts!
3. Smaller

#Get Older Versions

https://github.com/ilovecode1/video.js-del-plugin/commits/bc019a4c06b297f71457db29936a781388efa4b9/del.js

#What is Video.js?

Video.js is a extendable, custom HTML5 Video player. Learn more at http://videojs.com

#What does Doing Ending Leaving mean?

##Doing

* Shows Video
* It auto starts the video
* Makes it go full screen (you can change that part).

##Ending

* Turns off fullscreen
* Set HTML

##Leaving

* It Deletes the video from existance.

#How to use it?

* You can use for a intro to a website,
* A popup ad,
* And other reasons!

# setup

##1

````
<script src="path/to/del.js">
````

##2

```
<script>
del("yourVideoName",true /*true if you want it to auto fullscreen false if not!*/,"<p>The Video is Done!</p>")
</script>
```

##3

There is no 3rd step

