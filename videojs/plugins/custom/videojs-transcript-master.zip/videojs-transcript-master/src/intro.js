(function (window, videojs) {
  'use strict';

